/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <string.h>
#include <jni.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

#include "tremolo/Tremolo/ivorbisfile.h"

#define  LOG_TAG    "hello-jni"
#define  ALOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  ALOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

/* This is a trivial JNI example where we use a native method
 * to return a new VM String. See the corresponding Java source
 * file located at:
 *
 *   hello-jni/app/src/main/java/com/example/hellojni/HelloJni.java
 */

typedef struct _AudioDecoder
{
    long _fileCurrPos;
    unsigned char* _fileDataBytes;
    size_t _fileDataSize;
} AudioDecoder;

#define MIN(a, b) ((a) > (b) ? (b) : (a))

static AudioDecoder __decoder;
static AAssetManager* __assetManager;

static size_t fileRead(void* ptr, size_t size, size_t nmemb, void* datasource)
{
    AudioDecoder* thiz = (AudioDecoder*)datasource;
    ssize_t toReadBytes = MIN((ssize_t)(thiz->_fileDataSize - thiz->_fileCurrPos), (ssize_t)(nmemb * size));
    if (toReadBytes > 0)
    {
        memcpy(ptr, (unsigned char*) thiz->_fileDataBytes + thiz->_fileCurrPos, toReadBytes);
        thiz->_fileCurrPos += toReadBytes;
    }
    ALOGD("File size: %d, After fileRead _fileCurrPos %d, return : %d", (int)thiz->_fileDataSize, thiz->_fileCurrPos, (int)toReadBytes);
    return toReadBytes;
}

static int fileSeek(void* datasource, int64_t offset, int whence)
{
    AudioDecoder* thiz = (AudioDecoder*)datasource;
    if (whence == SEEK_SET)
        thiz->_fileCurrPos = offset;
    else if (whence == SEEK_CUR)
        thiz->_fileCurrPos = thiz->_fileCurrPos + offset;
    else if (whence == SEEK_END)
        thiz->_fileCurrPos = thiz->_fileDataSize;
    return 0;
}

static int fseek64Wrap(void* datasource, ogg_int64_t off, int whence)
{
    return fileSeek(datasource, (long)off, whence);
}

static int fileClose(void* datasource)
{
    return 0;
}

static long fileTell(void* datasource)
{
    AudioDecoder* thiz = (AudioDecoder*)datasource;
    return (long) thiz->_fileCurrPos;
}

static int decodeToPcm(const char* url)
{
    __decoder._fileCurrPos = 0;
    __decoder._fileDataBytes = NULL;
    __decoder._fileDataSize = 0;

    AAsset* aa = AAssetManager_open(__assetManager, url, AASSET_MODE_UNKNOWN);
    if (aa)
    {
        size_t size = (size_t)AAsset_getLength(aa);
        __decoder._fileDataSize = size;
        __decoder._fileDataBytes = (unsigned char*) malloc(size);
        int readsize = AAsset_read(aa, __decoder._fileDataBytes, size);
        ALOGD("readSize: %d", readsize);
        AAsset_close(aa);
    } else {
        ALOGE("[AssetManager] ... in APK %s, found = false!", url);
    }

    ov_callbacks callbacks;
    callbacks.read_func = fileRead;
    callbacks.seek_func = fseek64Wrap;
    callbacks.close_func = fileClose;
    callbacks.tell_func = fileTell;

    OggVorbis_File vf;
    int ret = ov_open_callbacks(&__decoder, &vf, NULL, 0, callbacks);
    if (ret != 0)
    {
        ALOGE("Open file error, file: %s, ov_open_callbacks return %d", url, ret);
        return -1;
    }
    // header
    vorbis_info* vi = ov_info(&vf, -1);

    uint32_t uiPCMSamples = (uint32_t) ov_pcm_total(&vf, -1);

    uint32_t bufferSize = uiPCMSamples * vi->channels * sizeof(short);
    char* pvPCMBuffer = (char*)malloc(bufferSize);
    memset(pvPCMBuffer, 0, bufferSize);

    int currentSection = 0;
    long curPos = 0;
    long readBytes = 0;
    // decode
    do {
        readBytes = ov_read(&vf, pvPCMBuffer + curPos, 4096, &currentSection);
        curPos += readBytes;
    } while (readBytes > 0);

    ov_clear(&vf);
    free(pvPCMBuffer);

    free(__decoder._fileDataBytes);
    __decoder._fileCurrPos = 0;
    __decoder._fileDataBytes = NULL;

    ALOGD("Decode finished!");
    return 0;
}

JNIEXPORT jstring JNICALL
Java_com_example_hellojni_HelloJni_stringFromJNI( JNIEnv* env,
                                                  jobject thiz, jobject assetManager )
{
#if defined(__arm__)
    #if defined(__ARM_ARCH_7A__)
    #if defined(__ARM_NEON__)
      #if defined(__ARM_PCS_VFP)
        #define ABI "armeabi-v7a/NEON (hard-float)"
      #else
        #define ABI "armeabi-v7a/NEON"
      #endif
    #else
      #if defined(__ARM_PCS_VFP)
        #define ABI "armeabi-v7a (hard-float)"
      #else
        #define ABI "armeabi-v7a"
      #endif
    #endif
  #else
   #define ABI "armeabi"
  #endif
#elif defined(__i386__)
#define ABI "x86"
#elif defined(__x86_64__)
#define ABI "x86_64"
#elif defined(__mips64)  /* mips64el-* toolchain defines __mips__ too */
#define ABI "mips64"
#elif defined(__mips__)
#define ABI "mips"
#elif defined(__aarch64__)
#define ABI "arm64-v8a"
#else
#define ABI "unknown"
#endif

    __assetManager = AAssetManager_fromJava(env, assetManager);
    decodeToPcm("SpecialSound.ogg");

    return (*env)->NewStringUTF(env, "Hello world from JNI !  Compiled with ABI " ABI ".");
}
